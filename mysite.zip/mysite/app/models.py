from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MaxValueValidator, MinValueValidator

STATE_CHOICES = (
    ('Bihar','Bihar'),
    ('Karnataka','Karnataka'),
)

# Create your models here.

class Customer(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    locality = models.CharField(max_length=200)
    city = models.CharField(max_length=200)
    zipcode = models.IntegerField()
    state = models.CharField(choices=STATE_CHOICES, max_length=50)

    def __str__(self):
        return str(self.id)
    

CATEGORY_CHOICES = (
    ('S', 'Stationery'),
    ('P','Print'),


)

class Product(models.Model):
    title = models.CharField(max_length=100)
    selling_price = models.FloatField()
    discounted_price = models.FloatField()
    description = models.TextField()
    brand = models.CharField(max_length=100)
    category = models.CharField( choices=CATEGORY_CHOICES, max_length=2)
    product_image = models.ImageField(upload_to = 'productimg')

    def __str__(self):
        return str(self.id)  

COLOR_CHOICES = (
    ('Black & White', 'Black & White'),
    ('Color','Color'),
)

PRINT_CHOICES = (
    ('Both Side', 'Both-Side'),
    ('Single side','Single-Side'),

)

CAMPUS_CHOICES = (
    ('HKBK', 'HKBK'),
    

)
# class PrintProduct(models.Model):
#     title = models.CharField(max_length=100)
#     campus = models.CharField(max_length=100)
    
#     pages = models.FloatField()
#     print_type = models.CharField(max_length=50) 
#     print_side = models.CharField(max_length=50)   
#     product_image = models.ImageField(upload_to = 'productimg')

#     def __str__(self):
#         return str(self.id)

class File(models.Model):

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    file = models.FileField(upload_to="")
    campus_name = models.CharField(choices=CAMPUS_CHOICES, max_length=100)
    print_type = models.CharField( choices=PRINT_CHOICES, max_length=50)
    print_color = models.CharField( choices=COLOR_CHOICES, max_length=50)
    pages = models.IntegerField()
    amount = models.IntegerField()
    
    
    def __str__(self):
        return str(self.id)


class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    

    def __str__(self):
        return str(self.id)

    
    @property
    def total_cost(self):
        return self.quantity * self.product.discounted_price

class PrintCart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    file = models.ForeignKey(File, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    

    def __str__(self):
        return str(self.id)

    
    @property
    def total_cost(self):
        return self.quantity * self.file.amount
    
STATUS_CHOICES = (
    ('Accepted','Accepted'),
    ('Ready','Ready'),
    
    ('Delivered','Delivered'),
    ('Cancel','Cancel')
)

class OrderPlaced(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    # customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    order_id = models.CharField(max_length=100)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    ordered_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=50, choices=STATUS_CHOICES,default='Pending')
   
   
    def __str__(self):
        return str(self.id)

    @property
    def total_cost(self):
        return self.quantity * self.product.discounted_price


class OrderPlacedFile(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    # customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    order_id = models.CharField(max_length=100)
    file = models.ForeignKey(File, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    ordered_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=50, choices=STATUS_CHOICES,default='Pending')
   
   
    def __str__(self):
        return str(self.id)

    @property
    def total_cost(self):
        return self.quantity * self.file.amount


    